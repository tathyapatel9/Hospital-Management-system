-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hospital_mage_sys
-- ------------------------------------------------------
-- Server version	5.5.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `iteams`
--

DROP TABLE IF EXISTS `iteams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `iteams` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `alternate_name` varchar(255) DEFAULT NULL,
  `expired_date` varchar(255) DEFAULT NULL,
  `gst_rate` float NOT NULL,
  `hsn_code` varchar(255) DEFAULT NULL,
  `item_code` varchar(255) DEFAULT NULL,
  `item_name` varchar(255) DEFAULT NULL,
  `material_id` int(11) DEFAULT NULL,
  `materialg_name` varchar(255) DEFAULT NULL,
  `price` double NOT NULL,
  `short_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `iteams`
--

LOCK TABLES `iteams` WRITE;
/*!40000 ALTER TABLE `iteams` DISABLE KEYS */;
INSERT INTO `iteams` VALUES (2,'Analgesic','2024-05-06',18,'3004','PH466',' Painkiller',2,'Pharmaceuticals',2500,'Pill'),(3,'Lab Scope','2025-02-06',5,'9018','LE123','Microscope',3,'Laboratory Equipment',100000,'Scope'),(4,'BP Machine','2027-06-18',18,'9018','DT123','Blood Pressure Monitor',4,'Diagnostic Tools',200000,'Monitor'),(5,'Surgical Knife','2024-05-06',18,'4015','SI12','Scalpel',6,'Surgical Instruments',2000,'Knife'),(6,'eyeDrops','2024-06-06',18,'23','Eye23','eyeDrops',11,'Eye Drops',1000,'drops'),(7,'Surgical Mask','2024-03-07',5,'6307','MS567','Face Mask',10,'Medical Supplies',599,'Mask'),(8,'Anti-infective','2024-07-10',12.5,'6307','Hm12','Antibiotic',9,'Harmaceuticals',200,'Pill'),(9,'BP Machine','2024-09-08',12.5,'4015','MS123','Blood Pressure Monitor',4,'Diagnostic Tools',600,'BMachin');
/*!40000 ALTER TABLE `iteams` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-18 19:23:08
