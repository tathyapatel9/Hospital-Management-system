-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: hospital_mage_sys
-- ------------------------------------------------------
-- Server version	5.5.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `patient`
--

DROP TABLE IF EXISTS `patient`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `patient` (
  `patient_id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `blood_grp` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `contact_num` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `diseases` varchar(255) DEFAULT NULL,
  `dob` varchar(255) DEFAULT NULL,
  `doc_path` varchar(255) DEFAULT NULL,
  `doc_type` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `maritial_status` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `otp` int(11) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `refferd_by` varchar(255) DEFAULT NULL,
  `registration_type` varchar(255) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`patient_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patient`
--

LOCK TABLES `patient` WRITE;
/*!40000 ALTER TABLE `patient` DISABLE KEYS */;
INSERT INTO `patient` VALUES (6,'Ahmedabad','o+','ahmedabad','9512881324','India ','No ','2024-02-28','9999123323','Aadharcard','ppavan.tec@gmail.com','Pavan','male','Prajapati','Unmarried','Rakeshbhai',168038,'$2a$10$yAwkppZ2PmftPUFT5vTxfuJSTTcC25loFChkbUeQ1FiRwBLNRijQa','383460','College','Public',5,'Gujarat'),(9,'surat','o+','surat','9512881324','india','Diabetes','2024-02-23','123321','voterid','raj.tec@gmail.com','Raj','male','Prajapati ','Married','L',NULL,'$2a$10$quo6d9FtNWQpzF.ME2AO6.pwEHQYxWSL3N1mIlM9hclHsR/iHcLRG','3242355','Any','Public',5,'Gujarat'),(10,'porbandar','o+','Porbandar','1234553','India ','No ','2024-03-06','123456','Aadharcard','harsh@gmail.com','Ramu','male','Rathod','Unmarried','H',NULL,'$2a$10$BOdPF3i4BuvErjshTTT1IOooUBsdJ2AN2z4kAs4FuFhpyB.RpP1fG','383460','collage','Private',5,'Gujarat'),(12,'surat','o+','ahmedabad','8799579987','India ','Migraine','2024-03-14','123321','Aadharcard','pavan@gmail.com',' Pavan ','male','Patel','Unmarried','L',NULL,'$2a$10$QqRZvSIRVqTus9IyIuezJ.vfR48ZajuLTJ4/J7qERGl9W7lPfQVNW','383460','College','Public',6,'Gujarat'),(14,'Delhi','o+','Delhi','123456789','India ','Depression','2003-05-06','12345','pancard','ankit@gmail.com','Ankit','male','Rathod','Unmarried','L',NULL,'$2a$10$Ek0kV8MV5.8oStALPPIEdOBHoE.ZpiTEd15.71l5TCJiPiFGNArTm','383460','Hospital','Public',5,'gujarat'),(15,'porbandar','B-','Porbandar','1234553','India ','Diabetes','1996-07-06','12345','pancard','rupali@gmail.com','Rupali','female','Panchal','Married','R',NULL,'$2a$10$oAy/lenjm1Tkqa8P3jq3e.bUKb6SmCChLtQglnttIaLXT1rIxLtP2','383460','collage','Public',5,'Gujarat'),(16,'surat','AB-','Surat','1234553','India ','Hypertension','2000-05-06','123321','Aadharcard','jay@gamil.com','Jay','male','shah','Married','N',NULL,'$2a$10$fYGmyUQ1sWgcZmIbYUR8hOrXE1Tc0q0ja.kBTsm6VqMM4OiDu7.o6','344342','Hospital','Public',5,'Gujarat'),(17,'Ahmedabad','B-','Thaltej,Ahmedabad','1234553','India ','Depression','2003-04-23','123321','pancard','ruchika@gmail.com','Ruchika','female','Nagar','Unmarried','M',NULL,'$2a$10$H/S5clL7D7pdHbB80793MuVMNwQ.3Nq49bkQARjkdL4Qodud2D0YK','383460','College','Public',5,'gujarat'),(18,'Ahmedabad','o+','ahmedabad','1234553','India ','Depression','2003-08-15','1234535','pancard','dev@gamil.com','Dev','male','Patel','Unmarried','S',NULL,'$2a$10$8KBZNlN6o1CzLvm3gK2AXuQflWF5bd1PhJKIw10H6glDkjctMKO.S','383460','College','Public',5,'Gujarat'),(19,'ahmedabad','o+','simla','9016818976','india','No ','2024-02-07','23456789','Aadharcard','naitikprajapati753@gmail.com','Naitik','male','Prajapati ','Unmarried','R',NULL,'$2a$10$62oZ0uj85DTSRYBkhwhQ8uzRAlKK3ngSO/0w.SL8z5T1LvI6vK/ry','383460','collage','Public',5,'gujarat'),(20,'Narol','A-','.','7990696999','.','Hypertension','2024-01-01','34456353342380989','Aadharcard','ashutosh@gmail.com','Ashutosh','male','Shakya','Unmarried','Sunilbhai',NULL,'$2a$10$nhnM7DGefU40J5oru33TauImdL/rNF.EZ2wbLJu.6e4T9VW6uXAFq','.','.','Private',5,'.'),(21,'Delhi','o+','Thaltej,Ahmedabad','8980179896','India ','No ','2024-03-22','123456','pancard','prajapatidharmik2812@gmail.com','dharmik','male','Prajapati ','Unmarried','R',NULL,'$2a$10$2T64AjwY8sSGgtnfKK1One9bj.38mRUDvXnl983U964.D1VZt.jXu','385255','College','Public',5,'gujarat');
/*!40000 ALTER TABLE `patient` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-18 19:23:09
